//
//  ViewController.m
//  Interaction
//
//  Created by KT-yzx on 2019/9/20.
//  Copyright © 2019 QuickTo. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>

@interface ViewController ()<WKScriptMessageHandler, WKNavigationDelegate>

@property (nonatomic, strong) WKWebView *wkWebView;

@end

@implementation ViewController


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.wkWebView.configuration.userContentController addScriptMessageHandler:self name:@"oh_initWithFrame"];
    [self.wkWebView.configuration.userContentController addScriptMessageHandler:self name:@"oh_backgroundColor"];

    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.wkWebView.configuration.userContentController removeScriptMessageHandlerForName:@"oh_initWithFrame"];
    [self.wkWebView.configuration.userContentController removeScriptMessageHandlerForName:@"oh_backgroundColor"];

    
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self loadWebView];
    
    
    
}

//加载本地的html文件
- (void)loadWebView
{
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    
    WKUserContentController *userCC = config.userContentController;
    //JS调用OC 添加处理脚本
    
    self.wkWebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, 0, 0) configuration:config];
    self.wkWebView.UIDelegate = self;
    self.wkWebView.navigationDelegate = self;
    
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSURL *baseURL = [NSURL fileURLWithPath:path];
    NSString *htmlPath = [[NSBundle mainBundle] pathForResource:@"File" ofType:@"html"];
    
    
    NSString *htmlCont = [NSString stringWithContentsOfFile:htmlPath
                                                   encoding:NSUTF8StringEncoding
                                                      error:nil];
    [self.wkWebView loadHTMLString:htmlCont baseURL:baseURL];
    
    [self.view addSubview:self.wkWebView];
    
    
}






#pragma mark - navigationDelegate


//页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    NSLog(@"开始加载2");
}

//内容返回时调用，得到请求内容时调用(内容开始加载) -> view的过渡动画可在此方法中加载
- (void)webView:(WKWebView *)webView didCommitNavigation:( WKNavigation *)navigation
{
    NSLog(@"内容返回时调用，得到请求内容时4");
    
}

//页面加载完成时调用
- (void)webView:(WKWebView *)webView didFinishNavigation:( WKNavigation *)navigation
{
    NSLog(@"页面加载完成时5");
    CGFloat width = [[UIScreen mainScreen] bounds].size.width;
    CGFloat height = [[UIScreen mainScreen] bounds].size.height;
    NSString * funcStr = [NSString stringWithFormat:@"widthAndHeight(%f,%f)", width, height];
    [self.wkWebView evaluateJavaScript:funcStr completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        //TODO
        NSLog(@"%@ %@",response,error);
    }];
    
}

//请求失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    NSLog(@"error1:%@",error);
}

-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    NSLog(@"error2:%@",error);
}

//在请求发送之前，决定是否跳转 -> 该方法如果不实现，系统默认跳转。如果实现该方法，则需要设置允许跳转，不设置则报错。
//该方法执行在加载界面之前
//Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'Completion handler passed to -[ViewController webView:decidePolicyForNavigationAction:decisionHandler:] was not called'
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    
    NSLog(@"url =========== %@", navigationAction.request.URL);
    
    
    
    //允许跳转
    decisionHandler(WKNavigationActionPolicyAllow);
    
    //不允许跳转
    //        decisionHandler(WKNavigationActionPolicyCancel);
    NSLog(@"在请求发送之前，决定是否跳转 1");
}

//在收到响应后，决定是否跳转（同上）
//该方法执行在内容返回之前
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
{
    //允许跳转
    decisionHandler(WKNavigationResponsePolicyAllow);
    //不允许跳转
    //    decisionHandler(WKNavigationResponsePolicyCancel);
    NSLog(@"在收到响应后，决定是否跳转。 3");
    
}

//接收到服务器跳转请求之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    NSLog(@"接收到服务器跳转请求之后调用");
}

-(void)webViewWebContentProcessDidTerminate:(WKWebView *)webView
{
    NSLog(@"webViewWebContentProcessDidTerminate");
}

#pragma mark - WKScriptMessageHandler

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    NSLog(@"message.name = %@",message.name);
    NSLog(@"message.body = %@",message.body);
    
    if ([message.name isEqualToString:@"oh_initWithFrame"]) {
        
        NSArray *array = message.body;
        [self oh_initWithFrame:array];
        
    }
    if ([message.name isEqualToString:@"oh_backgroundColor"]) {//
        
        NSArray *array = message.body;
        [self oh_backgroundColor:array];
        
    }
    
    
}

#pragma mark - UI控件的调用


- (void)oh_init{
    
    
}

- (void)oh_initWithFrame:(NSArray *)model{
    if (model.count < 6) {
        return;
    }
    
    NSString * getView = (NSString *)[model objectAtIndex:0];
    NSString * getTag = (NSString *)[model objectAtIndex:1];
    NSString * x = (NSString *)[model objectAtIndex:2];
    NSString * y = (NSString *)[model objectAtIndex:3];
    NSString * width = (NSString *)[model objectAtIndex:4];
    NSString * height = (NSString *)[model objectAtIndex:5];
    
    
    
    if ([getView isEqualToString:@"UIView"]) {
        
        UIView * selectView = [[UIView alloc] initWithFrame:CGRectMake([x floatValue], [y floatValue], [width floatValue], [height floatValue])];
        selectView.tag = [getTag integerValue];
        [self.view addSubview:selectView];
        
    }else if ([getView isEqualToString:@"UIButton"]){
        
        UIButton * selectView = [[UIButton alloc] initWithFrame:CGRectMake([x floatValue], [y floatValue], [width floatValue], [height floatValue])];
        selectView.tag = [getTag integerValue];
        [self.view addSubview:selectView];
        
    }else if ([getView isEqualToString:@"UIImageView"]){
        
        UIImageView * selectView = [[UIImageView alloc] initWithFrame:CGRectMake([x floatValue], [y floatValue], [width floatValue], [height floatValue])];
        selectView.tag = [getTag integerValue];
        [self.view addSubview:selectView];
        
    }
    
}

- (void)oh_backgroundColor:(NSArray *)model{
    
    if (model.count < 5) {
        return;
    }
    NSString * getTag = (NSString *)[model objectAtIndex:0];
    NSString * red = (NSString *)[model objectAtIndex:1];
    NSString * green = (NSString *)[model objectAtIndex:2];
    NSString * blue = (NSString *)[model objectAtIndex:3];
    NSString * alpha = (NSString *)[model objectAtIndex:4];
    
    
    float redFloat = [red floatValue];
    float greenFloat = [green floatValue];
    float blueFloat = [blue floatValue];
    float alphaFloat = [alpha floatValue];
    UIView * ohView = [self.view viewWithTag:[getTag integerValue]];
    ohView.backgroundColor = [UIColor colorWithRed:redFloat/255.0 green:greenFloat/255.0 blue:blueFloat/255.0 alpha:alphaFloat];
    
    
}



@end
